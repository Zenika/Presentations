package com.zenika.android.park.ui.maps;

import android.content.Context;
import com.google.android.maps.GeoPoint;
import com.google.android.maps.OverlayItem;
import com.zenika.android.park.model.pojo.Parking;

public class ParkingOverlayItem extends OverlayItem {

	//	@Override
	//	public Drawable getMarker(int stateBitset) {
	//		switch (mParking.getState()) {
	//			case SURE_NOT:
	//				return ParkingOverlay.getRedMarker(mContext);
	//			case MAY_NOT:
	//			case IS:
	//				return ParkingOverlay.getGreenMarker(mContext);
	//			default:
	//				return null;
	//		}
	//	}

	//	public Parking getParking() {
	//		return mParking;
	//	}

}
