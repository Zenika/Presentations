package com.zenika.android.park.model.db;

import com.zenika.android.tools.utils.PrefsManager;


public class Prefs extends PrefsManager {

	public static final String UI_PRFS = "_ui_prefs_name_";
	

	public static final String INIT_V = "_ui_init_version_key";
	public static final String MAP_ACCURACY = "_ui_map_accuracy_key";

}
